function cargaContextoCanvas(IdCanvas) {
    let elemento = document.getElementById(IdCanvas);
    if (elemento && elemento.getContext) {
        let contexto = elemento.getContext('2d');
        if (contexto) {
            return contexto;
        }
    }
    return false;
}


window.addEventListener("DOMContentLoaded", function () {
    let contexto = cargaContextoCanvas('micanvas');
    if (contexto) {
        // Estrellas
        let estrella = new Image();
        estrella.src = 'estrellas.png';
        estrella.addEventListener('load', function () {
            contexto.drawImage(estrella, 0, 0, 150, 150);
            contexto.drawImage(estrella, 120, 475, 200, 200);
            contexto.drawImage(estrella, 200, 300, 250, 250);
            contexto.drawImage(estrella, 200, 0, 250, 250);
            contexto.drawImage(estrella, 10, 250, 150, 150);
        });

        // Función para el movimiento lunar
        let lunaY = 1047;
        let velocidadLuna = 1;

        function movimientoLunar() {
            // Borra el canvas
            contexto.clearRect(0, 0, 600, 800);

            // Dibuja las estrellas nuevamente
            contexto.drawImage(estrella, 0, 0, 150, 150);
            contexto.drawImage(estrella, 120, 475, 200, 200);
            contexto.drawImage(estrella, 200, 300, 250, 250);
            contexto.drawImage(estrella, 200, 0, 250, 250);
            contexto.drawImage(estrella, 10, 250, 150, 150);

            lunaY += velocidadLuna;

            // Cohete cuerpo
            contexto.fillStyle = 'white';
            contexto.fillRect(200, 275, 80, 200);
            contexto.strokeRect(200, 275, 80, 200);

            // Cohete techo
            contexto.beginPath();
            contexto.moveTo(200, 275);
            contexto.lineTo(240, 175);
            contexto.lineTo(280, 275);
            contexto.fill();
            contexto.stroke();

            // Ventanas
            contexto.fillStyle = "gray";
            contexto.fillRect(210, 310, 60, 40);
            contexto.fillStyle = 'lightblue';
            contexto.fillRect(215, 315, 20, 30);
            contexto.fillRect(245, 315, 20, 30);

            // Fuego
            contexto.fillStyle = 'red';
            contexto.beginPath();
            contexto.moveTo(200, 475);
            contexto.lineTo(215, 515);
            contexto.lineTo(230, 475);
            contexto.lineTo(240, 515);
            contexto.lineTo(250, 475);
            contexto.lineTo(265, 515);
            contexto.lineTo(280, 475);
            contexto.closePath();
            contexto.fill();
            contexto.stroke();

            contexto.fillStyle = 'yellow';
            contexto.beginPath();
            contexto.moveTo(207, 475);
            contexto.lineTo(215, 500);
            contexto.lineTo(223, 475);
            contexto.closePath();
            contexto.fill();

            contexto.beginPath();
            contexto.moveTo(257, 475);
            contexto.lineTo(265, 500);
            contexto.lineTo(273, 475);
            contexto.closePath();
            contexto.fill();

            // Dibuja la luna
            contexto.fillStyle = '#FFF868';
            contexto.beginPath();
            contexto.arc(240, lunaY, 576, 0, Math.PI * 2, false);
            contexto.closePath();
            contexto.fill();

            // Solicita el próximo cuadro de animación
            requestAnimationFrame(movimientoLunar);
        }

        // Inicia la animación lunar
        movimientoLunar();
    }
});